export interface JSONObject {
    [key: string]: unknown;
}
export type StructuredFileFormat = 'json' | 'yaml' | 'dotenv';
export declare function inferStructuredFileFormat(sopsFilePath: string): StructuredFileFormat | undefined;
export declare function parseStructuredFile(sopsFilePath: string, fileFormat?: StructuredFileFormat): JSONObject;
export declare function flattenStructuredFile(sopsFilePath: string, keySeparator: string, fileFormat?: StructuredFileFormat): JSONObject;
export declare function flattenStructuredFileToStringMap(sopsFilePath: string, keySeparator: string, fileFormat?: StructuredFileFormat): Record<string, string>;
