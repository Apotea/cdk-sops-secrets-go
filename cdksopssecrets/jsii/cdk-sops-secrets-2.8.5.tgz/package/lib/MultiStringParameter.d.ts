import { IKey } from 'aws-cdk-lib/aws-kms';
import { ResourceEnvironment, Stack } from 'aws-cdk-lib/core';
import { Construct } from 'constructs';
import { SopsCommonParameterProps } from './SopsStringParameter';
import { SopsSync } from './SopsSync';
export interface MultiStringParameterProps extends SopsCommonParameterProps {
    /**
     * The separator used to separate keys
     *
     * @default - '/'
     */
    readonly keySeparator?: string;
    /**
     * The prefix used for all parameters
     *
     * @default - '/'
     */
    readonly keyPrefix?: string;
}
export declare class MultiStringParameter extends Construct {
    readonly sync: SopsSync;
    readonly encryptionKey: IKey;
    readonly stack: Stack;
    readonly env: ResourceEnvironment;
    readonly keyPrefix: string;
    readonly keySeparator: string;
    constructor(scope: Construct, id: string, props: MultiStringParameterProps);
    private parseFile;
}
